            </div>
        </div>

        <script src="<?php echo site_url('resources/js/waitMe.js');?>"></script>
        <!-- Bootstrap -->
        <script src="<?php echo site_url('resources/js/bootstrap.min.js');?>"></script>
        <script src="<?php echo site_url('resources/js/parsley.extend.js');?>"></script>
        <script src="<?php echo site_url('resources/js/parsley.min.js');?>"></script>
        <!-- Custom Theme Scripts -->
        <script src="<?php echo site_url('resources/js/custom.min.js');?>"></script>
    </body>
</html>  